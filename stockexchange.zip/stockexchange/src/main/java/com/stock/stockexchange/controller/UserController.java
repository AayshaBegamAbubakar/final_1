package com.stock.stockexchange.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(path = "/sign", method = RequestMethod.GET)

	public String getSignForm(ModelMap model) {
		System.out.println("get empty user pojo");
		User user = new User();
		model.addAttribute("user", user);
		System.out.println("go to home page");

		return "Home";

	}

	@RequestMapping(path = "/signup", method = RequestMethod.GET)

	public ModelAndView formHandler(@Valid @ModelAttribute("user") User user,

			BindingResult result, Model model) {

		System.out.println("choose sign up");
		ModelAndView mv = new ModelAndView();
		User insertedUser;
		if (result.hasErrors()) {

			System.out.println("errors occured");

			System.out.println(result.getAllErrors());

			model.addAttribute("user", user);

			mv.setViewName("Home");

		}
		try {
			System.out.println("user  insert method in service calling");
			insertedUser = userService.insertUser(user);
			mv.setViewName("Home");
			if (insertedUser != null) {
				System.out.println("after user inserted");
				System.out.println(insertedUser);
			} else {
				System.out.println(" user not inserted");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return mv;

	}

	@RequestMapping(path = "/signin", method = RequestMethod.GET)

	public ModelAndView getSignIn(@Valid @ModelAttribute("user") User user,

			BindingResult result, Model model) throws SQLException {

		System.out.println("inside signin call");
		ModelAndView mv = new ModelAndView();
		User validateUser;
		if (result.hasErrors()) {

			System.out.println("errors occured");

			System.out.println(result.getAllErrors());

			model.addAttribute("user", user);

			mv.setViewName("Home");

		}
		System.out.println("user validate method calling");
		validateUser = userService.validateUser(user);
		mv.setViewName("Sign");
		if (validateUser!=null) {
			System.out.println("correct username and password");
			System.out.println(validateUser);
		} else {
			System.out.println("Wrong user");
		}

		return mv;

	}

}
