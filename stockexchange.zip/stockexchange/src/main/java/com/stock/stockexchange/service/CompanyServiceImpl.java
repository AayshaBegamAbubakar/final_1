package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.CompanyDao;
import com.stock.stockexchange.dao.SectorDao;
import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
@Service

public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private SectorDao  sectorDao;
	
	@Autowired
	private CompanyDao  companyDao;
	
	
	
	

	@Override
	public List<Sector> getCompanyList() throws SQLException, ClassNotFoundException {
		return sectorDao.findAll();
	}





	@Override
	public Company insertCompany(Company company) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}





	public List<Company> findByPattern(String match) {
		// TODO Auto-generated method stub
		return companyDao.findByPattern(match);
	}
	
	

}

