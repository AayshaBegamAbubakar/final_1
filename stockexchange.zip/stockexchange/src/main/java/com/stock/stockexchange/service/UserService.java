package com.stock.stockexchange.service;

import java.sql.SQLException;

import javax.validation.Valid;

import com.stock.stockexchange.model.User;

public interface UserService {
	  public User insertUser(User user) throws SQLException;

	public User validateUser(@Valid User user);
}
