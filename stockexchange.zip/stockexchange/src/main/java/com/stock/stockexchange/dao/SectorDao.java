package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.Sector;


public interface SectorDao extends JpaRepository<Sector,Integer>{
	// gives both sector data and company data using many to one mapping
	@Query("Select s From Sector s where s.sectorId = :sectorId")
	List<Sector> findBySectorId(@Param("sectorId") int sectorId);
}
