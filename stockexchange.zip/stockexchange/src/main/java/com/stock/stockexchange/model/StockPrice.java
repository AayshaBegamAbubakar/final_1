package com.stock.stockexchange.model;

import java.util.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.Table;

@Entity
@Table(name="stock_price")
public class StockPrice {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stock_price_id")
	private int stockPriceId;
	
	
	@Column(name="stock_exchange_id")
	private int stockExhcangeId;
	
	@Column(name="company_id")
	private int companyId;
	
	@Column(name="current_price")
	private float curentPrice;
	
	@Column(name="date")
	private Date date;
	
	@Column(name="time")
	private Date time;
	
	
	
	 
	public StockPrice(int id, int companyid2, int stockexchangeid, float currentPrice, Date dateinexcel,
			Date timeinexcel) {
		this.stockPriceId=id;
		this.companyId=companyid2;
		this.stockExhcangeId=stockexchangeid;
		this.curentPrice=currentPrice;
		this.date=dateinexcel;
		this.time=timeinexcel;
	}
	public int getStockPriceId() {
		return stockPriceId;
	}
	public void setStockPriceId(int stockPriceId) {
		this.stockPriceId = stockPriceId;
	}
	
	
	public float getCurentPrice() {
		return curentPrice;
	}
	public void setCurentPrice(float curentPrice) {
		this.curentPrice = curentPrice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	
	public int getStockExhcangeId() {
		return stockExhcangeId;
	}
	public void setStockExhcangeId(int stockExhcangeId) {
		this.stockExhcangeId = stockExhcangeId;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	
	

}
